package com.example.adapterstuff;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class Pokemon implements Parcelable {
    int image;
    String name;
    String type;
    String abilities;
    String color;
    String funFact;
    public Pokemon(String name, int image, String type, String abilities, String color, String funFact){
        this.image = image;
        this.name = name;
        this.type = type;
        this.abilities = abilities;
        this.color = color;
        this.funFact = funFact;
    }

    protected Pokemon(Parcel in) {
        image = in.readInt();
        name = in.readString();
        type = in.readString();
        abilities = in.readString();
        color = in.readString();
        funFact = in.readString();
    }

    public static final Creator<Pokemon> CREATOR = new Creator<Pokemon>() {
        @Override
        public Pokemon createFromParcel(Parcel in) {
            return new Pokemon(in);
        }

        @Override
        public Pokemon[] newArray(int size) {
            return new Pokemon[size];
        }
    };

    public String getName(){
        return name;
    }
    public String getType(){
        return type;
    }
    public int getImage(){
        return image;
    }
    public String getAbility(){ return abilities; }
    public String getColor(){return color;}
    public String getFunFact(){return funFact;}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(image);
        dest.writeString(name);
        dest.writeString(type);
        dest.writeString(abilities);
        dest.writeString(color);
        dest.writeString(funFact);
    }
}

