package com.example.adapterstuff;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ArrayList<Pokemon> pokeList = new ArrayList<Pokemon>();
    String ff;

    ListView listView;
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("Pokemon", pokeList);
        outState.putString("ff", ff);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.list_id);
        TextView extra = findViewById(R.id.textView9);
        TextView extra2 = findViewById(R.id.textView5);
        if(savedInstanceState==null||!savedInstanceState.containsKey("Pokemon")) {
            Pokemon pikachu = new Pokemon("Pikachu", R.drawable.pikachu2, "Electric", "static", "Color: yellow", "Pikachu likes ketchup");
            Pokemon eevee = new Pokemon("Eevee", R.drawable.eev2, "normal", "run away", "Color: brown", "OG name: Eon");
            Pokemon charizard = new Pokemon("Charizard", R.drawable.charizard2, "fire, flying", "blaze", "Color: orange", "12.5% female");
            Pokemon umbreon = new Pokemon("Umbreon", R.drawable.umbr2, "dark", "synchronize", "Color: black", "evolved form of Eevee");
            Pokemon milotic = new Pokemon("Milotic", R.drawable.milotic, "water", "marvel scale", "Color: cream", "Good for defense");
            pokeList.add(pikachu);
            pokeList.add(eevee);
            pokeList.add(charizard);
            pokeList.add(umbreon);
            pokeList.add(milotic);
        }
        else{
            pokeList = savedInstanceState.getParcelableArrayList("Pokemon");
        }


        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {

            CustomAdapter adapter = new CustomAdapter(this, R.layout.adapter_layout, pokeList);
            if(savedInstanceState==null||!savedInstanceState.containsKey("ff")) {
                extra2.setText("");
            }
            else{
                extra2.setText(savedInstanceState.getString("ff"));
            }
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    extra2.setText(pokeList.get(position).getFunFact());
                    ff = extra2.getText().toString();


                }
            });
        }
        else{
            CustomAdapter adapter = new CustomAdapter(this, R.layout.adapter_horizontal_layout, pokeList);
            if(savedInstanceState==null||!savedInstanceState.containsKey("ff")) {
                extra.setText("");
            }
            else{
                extra.setText(savedInstanceState.getString("ff"));
            }
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    extra.setText(pokeList.get(position).getFunFact());
                    ff = extra.getText().toString();
                }
            });
        }

    }

}