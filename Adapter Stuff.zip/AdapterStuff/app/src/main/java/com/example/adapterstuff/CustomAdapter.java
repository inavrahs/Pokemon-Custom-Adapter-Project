package com.example.adapterstuff;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.adapterstuff.Pokemon;
import com.example.adapterstuff.R;

import java.io.Console;
import java.util.List;

public  class CustomAdapter extends ArrayAdapter<Pokemon> {
    List<Pokemon> list;
    Context context;
    int xmlResource;

    public CustomAdapter(@NonNull Context context, int resource, @NonNull List<Pokemon> objects) {
        super(context, resource, objects);
        xmlResource = resource;
        list = objects;
        this.context = context;
    }

    public View getView (int position, @Nullable View convertView, @NonNull ViewGroup parent){
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View adapterLayout = layoutInflater.inflate(xmlResource, null);
        if(context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {

            TextView name = adapterLayout.findViewById(R.id.textView);
            TextView type = adapterLayout.findViewById(R.id.textView2);
            ImageView image = adapterLayout.findViewById(R.id.imageView);

            Button remove = adapterLayout.findViewById(R.id.button);

            remove.setText("Remove");
            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Pokemon a = list.remove(position);
                    notifyDataSetChanged();
                }
            });
            name.setText(list.get(position).getName());
            type.setText(list.get(position).getType());
            image.setImageResource(list.get(position).getImage());
            //extra.setText(list.get(position).getAbility());
        }
        else{
            RadioGroup rg = adapterLayout.findViewById(R.id.radiogroup);
            RadioButton rb1 = adapterLayout.findViewById(R.id.radioButton);
            RadioButton rb2 = adapterLayout.findViewById(R.id.radioButton2);
            TextView t2 = adapterLayout.findViewById(R.id.textView3);
            rb1.setChecked(true);
            t2.setText(list.get(position).getColor());
            ImageView image = adapterLayout.findViewById(R.id.imageView2);
            image.setImageResource(list.get(position).getImage());
            Button remove = adapterLayout.findViewById(R.id.button2);

            remove.setText("Remove");
            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Pokemon a = list.remove(position);
                    notifyDataSetChanged();
                }
            });
            rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    if(rb1.isChecked())
                        t2.setText(list.get(position).getColor());
                    else
                        t2.setText(list.get(position).getAbility());

                }
            });
        }
        return adapterLayout;
    }
}